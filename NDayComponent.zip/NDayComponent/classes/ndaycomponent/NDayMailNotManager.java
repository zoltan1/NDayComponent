package ndaycomponent;

import intradoc.common.ExecutionContext;
import intradoc.common.FileUtils;
import intradoc.common.ServiceException;
import intradoc.data.DataBinder;
import intradoc.data.DataException;
import intradoc.data.DataResultSet;
import intradoc.data.ResultSet;
import intradoc.data.Workspace;
import intradoc.resource.ResourceUtils;
import intradoc.server.ComponentLoader;
import intradoc.server.DirectoryLocator;
import intradoc.server.InternetFunctions;
import intradoc.server.Service;
import intradoc.shared.SharedObjects;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Map;


/**
 * Sending warning mail.
 * 
 * author: Zoltan Molnar
 **/
public class NDayMailNotManager extends Service
{
	
	public void getParameters() throws ServiceException, DataException {
		
		
		String everyNDays = "";
		String hourToExec = "";
		String longerThanInDays = "";
		String mailSubject = "";
		String mailMessage = "";
		String selectMetadata = "";
		String defaultDDocName = "";
		String defaultDDocTitle = "";
		String maxDays = "";
		
		try
		{
			FileInputStream fstream = new FileInputStream(ComponentLoader.getComponentDir("NDayComponent") + "\\templates\\nDay_config.cfg");

			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			
			while ((strLine = br.readLine()) != null)
			{
				//String strLine;
				String tmpName = strLine.substring(0, strLine.indexOf("="));
				String tmpValue = strLine.substring(strLine.indexOf("=") + 1, strLine.length());

				System.out.println(tmpName + "=" + tmpValue);
				if (tmpName.equals("everyNDays")) {
					everyNDays = tmpValue;
				}
				if (tmpName.equals("hourToExec")) {
					hourToExec = tmpValue;
				}
				if (tmpName.equals("longerThanInDays")) {
					longerThanInDays = tmpValue;
				}
				if (tmpName.equals("mailSubject")) {
					mailSubject = tmpValue;
				}
				if (tmpName.equals("mailMessage")) {
					mailMessage = tmpValue;
				}
				if (tmpName.equals("selectMetadata")) {
					selectMetadata = tmpValue;
				}
				if (tmpName.equals("defaultDDocName")) {
					defaultDDocName = tmpValue;
				}
				if (tmpName.equals("defaultDDocTitle")) {
					defaultDDocTitle = tmpValue;
				}
				if (tmpName.equals("maxDays")) {
					maxDays = tmpValue;
				}
				
			}
			in.close();
		}
		catch (Exception e)
		{
			System.out.println("File nDay_config.cfg can't be found!");
		}
		this.m_binder.putLocal("everyNDays", everyNDays);
		this.m_binder.putLocal("hourToExec", hourToExec);
		this.m_binder.putLocal("longerThanInDays", longerThanInDays);
		this.m_binder.putLocal("mailSubject", mailSubject);
		this.m_binder.putLocal("mailMessage", mailMessage);
		this.m_binder.putLocal("selectMetadata", selectMetadata);
		this.m_binder.putLocal("defaultDDocTitle", defaultDDocTitle);
		this.m_binder.putLocal("defaultDDocName", defaultDDocName);
		this.m_binder.putLocal("maxDays", maxDays);
	
	}

	public void saveParameters() throws ServiceException, DataException {
		
		String everyNDays = this.m_binder.getLocal("everyNDays");
		String hourToExec = this.m_binder.getLocal("hourToExec");
		String longerThanInDays = this.m_binder.getLocal("longerThanInDays");
		String mailSubject = this.m_binder.getLocal("mailSubject");
		String mailMessage = this.m_binder.getLocal("mailMessage");
		String selectMetadata = this.m_binder.getLocal("selectMetadata");

		String defaultDDocTitle = this.m_binder.getLocal("defaultDDocTitle");
		String defaultDDocName = this.m_binder.getLocal("defaultDDocName");
		
		try
		{
			
			FileWriter fstream = new FileWriter(ComponentLoader.getComponentDir("NDayComponent") + "\\templates\\nDay_config.cfg", false);
			BufferedWriter out = new BufferedWriter(fstream);
			out.write("everyNDays=" + everyNDays + 
					"\nhourToExec=" + hourToExec + 
					"\nlongerThanInDays=" + longerThanInDays + 
					"\nmailSubject=" + mailSubject + 
					"\nmailMessage=" + mailMessage + 
					"\nselectMetadata=" + selectMetadata + 
					"\ndefaultDDocTitle=" + defaultDDocTitle + 
					"\ndefaultDDocName=" + defaultDDocName);

			out.close();

			this.m_binder.putLocal("RedirectUrl", "<$HttpCgiPath$>?IdcService=NDAY_FORM");
		}
		catch (Exception e)
		{
			System.err.println("Error: " + e.getMessage());
		}
	}

	
	public void testSend1() throws ServiceException, DataException {
		
		String testdUser = this.m_binder.getLocal("testdUser");
		String testTodUser = this.m_binder.getLocal("testTodUser");

		System.out.println("--> testdUser " + testdUser);
		System.out.println("--> testTodUser " + testTodUser);

		String everyNDays = "";
		String hourToExec = "";
		String longerThanInDays = "";
		String mailSubject = "";
		String mailMessage = "";
		String selectMetadata = "";
		String defaultDDocName = "";
		String defaultDDocTitle = "";
		String maxDays = "";
		
		try
		{
			FileInputStream fstream = new FileInputStream(ComponentLoader.getComponentDir("NDayComponent") + "\\templates\\nDay_config.cfg");

			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			while ((strLine = br.readLine()) != null)
			{
				//String strLine;
				String tmpName = strLine.substring(0, strLine.indexOf("="));
				String tmpValue = strLine.substring(strLine.indexOf("=") + 1, strLine.length());

				System.out.println(tmpName + "=" + tmpValue);
				if (tmpName.equals("everyNDays")) {
					everyNDays = tmpValue;
				}
				if (tmpName.equals("hourToExec")) {
					hourToExec = tmpValue;
				}
				if (tmpName.equals("longerThanInDays")) {
					longerThanInDays = tmpValue;
				}
				if (tmpName.equals("mailSubject")) {
					mailSubject = tmpValue;
				}
				if (tmpName.equals("mailMessage")) {
					mailMessage = tmpValue;
				}
				if (tmpName.equals("selectMetadata")) {
					selectMetadata = tmpValue;
				}
				if (tmpName.equals("defaultDDocName")) {
					defaultDDocName = tmpValue;
				}
				if (tmpName.equals("defaultDDocTitle")) {
					defaultDDocTitle = tmpValue;
				}
				if (tmpName.equals("maxDays")) {
					maxDays = tmpValue;
				}
			}
			in.close();
		}
		catch (Exception e)
		{
			System.out.println("File nDay_config.cfg can't be found!");
		}
		if (!longerThanInDays.equals(""))
		{
			DataBinder serviceBinder = new DataBinder(SharedObjects.getSafeEnvironment());
			String rootPath = DirectoryLocator.getUserProfilesDir() + "\\" + testdUser.substring(0, 2) + "\\" + testdUser + "\\" + "wf_in_queue.hda";

			ResourceUtils.serializeDataBinder(FileUtils.getDirectory(new File(rootPath).toString()), FileUtils.getName(new File(rootPath).toString()), serviceBinder, false, true);

			Map map = serviceBinder.m_resultSets;

			serviceBinder.clearResultSets();
			serviceBinder.getLocalData().clear();

			DataResultSet resultSetDocumentsInWF = (DataResultSet)map.get("WorkflowInQueue");
			if (resultSetDocumentsInWF != null)
			{
				String subjekt = mailSubject;
				String poruka = mailMessage + "<br><br>";
				//String poruka1 = "<br><br>";

				poruka = poruka + "<table border=1>";
				//poruka1 = poruka1 + "<table border=1>";

				String porukaDokumenti = "";
				//String porukaDokumentiMax = "";

				int cnt = 1;
				//int cnt1 = 1;
				
				for (resultSetDocumentsInWF.first(); resultSetDocumentsInWF.isRowPresent();)
				{
					String dIDDocInWF = resultSetDocumentsInWF.getStringValueByName("dID");
					String dDocNameDocInWF = resultSetDocumentsInWF.getStringValueByName("dDocName");
					Timestamp wfQueueEnterTs = new Timestamp(resultSetDocumentsInWF.getDateValueByName("wfQueueEnterTs").getTime());

					Timestamp trenutniDatumTs = new Timestamp(new Date().getTime());

					long razlikaDatuma = Math.abs(trenutniDatumTs.getTime() - wfQueueEnterTs.getTime());

					Long longerThanInDaysLong = new Long(longerThanInDays);
					Long maxDaysLong = new Long(maxDays); //ovo je uvedeno zato jel su htjeli ako je račun kod korisnika više od 7 dana nije obrađen treba se poslati njegovom rukovoditelju i njemu samome
					
					if (razlikaDatuma > new Long(longerThanInDaysLong.longValue() * 24L * 60L * 60L * 1000L).longValue())
					{
						String sqlSelectMetadata = selectMetadata;
						if (!selectMetadata.equals("")) {
							sqlSelectMetadata = selectMetadata + ",";
						}
						String sqlGetCustom = "select " + sqlSelectMetadata + " dDocTitle from docmeta,revisions where docmeta.did=revisions.did and docmeta.did=" + dIDDocInWF;
						ResultSet tempCustom = this.m_workspace.createResultSetSQL(sqlGetCustom);

						String tempdefaultDDocName = "";
						if (defaultDDocName.equals("on")) {
							tempdefaultDDocName = 
									"<td><a href='<$HttpCgiPath$>?IdcService=REVIEW_WORKFLOW_DOC&dDocName=" + dDocNameDocInWF + "'>" + dDocNameDocInWF + "</a></td>";
						}
						String tempdefaultDDocTitle = "";
						if (defaultDDocTitle.equals("on")) {
							tempdefaultDDocTitle = "<td align=right>" + tempCustom.getStringValueByName("dDocTitle") + "</td>";
						}
						String tdSelectMetadata = "";
						if (!selectMetadata.equals("")) {
							if (tempCustom.getStringValueByName(selectMetadata) == null) {
								tdSelectMetadata = "<td align=center></td>";
							} else {
								tdSelectMetadata = "<td align=center>" + tempCustom.getStringValueByName(selectMetadata) + "</td>";
							}
						}
						porukaDokumenti = 

								porukaDokumenti + "<tr><td align=right>" + cnt + ".</td>" + tempdefaultDDocName + tempdefaultDDocTitle + tdSelectMetadata + "<td align=right>>" + new Long(razlikaDatuma / 86400000L).intValue() + "_days</td>" + "</tr>";

						cnt++;
					}
					
					
					// ovdje provjeravamo dali je račun više od 7 dana kod korisnika
					if (razlikaDatuma > new Long(maxDaysLong.longValue() * 24L * 60L * 60L * 1000L).longValue())
					{
						
						
						// prvo si preprim listu računa koji su više od 7 dana
						String sqlGetMeta1 = 
								"select xUrudzbeniBroj,dDocTitle,xTipDokumenta,xStatusDokumenta,dDocName " + 
								"from docmeta,revisions where docmeta.did=revisions.did and docmeta.did=" + dIDDocInWF;
						
						ResultSet tempRS1 = this.m_workspace.createResultSetSQL(sqlGetMeta1);
						
						String sUrBroj1 = tempRS1.getStringValueByName("xUrudzbeniBroj");
						String sDocTitle1 = tempRS1.getStringValueByName("dDocTitle");
						String sTipDoc1 = tempRS1.getStringValueByName("xTipDokumenta");
						String sStatDok1 = tempRS1.getStringValueByName("xStatusDokumenta");
						String sDokName1 = tempRS1.getStringValueByName("dDocName");
						
						
						/*if(sTipDoc1.equals("Račun")) {
							
							if(sStatDok1.equals("Na zaduženju") || sStatDok1.equals("na odobrenju")) {
								
								porukaDokumentiMax = porukaDokumentiMax + "<tr><td align=right>" + cnt1 + ".</td><td>" + sUrBroj1 + "</td></tr>";
								System.out.println("porukaDokumentiMax " + porukaDokumentiMax);
							}
						}*/
						
						
						
						//cnt1++;
					}

					
					
					resultSetDocumentsInWF.next();
				}
				poruka = poruka + porukaDokumenti + "</table>";
				poruka = poruka + "<br>Total documents: " + (cnt - 1) + "<br><br>";
				serviceBinder.putLocal("poruka", poruka);
				this.m_binder.putLocal("poruka", poruka);
				
				/*poruka1 = poruka1 + porukaDokumentiMax + "</table>";
				poruka1 = poruka1 + "<br>Total documents: " + (cnt1 - 1) + "<br><br>";
				serviceBinder.putLocal("poruka1", poruka1);
				this.m_binder.putLocal("poruka1", poruka1);*/
				

				//System.out.println("PORUKA DOKUMENTI!!!!!!!! " + porukaDokumenti);
				
				if (!porukaDokumenti.equals(""))
				{
					

					DataResultSet drs = SharedObjects.getTable("Users");

					String email = "";
					String user = "";
					
					for (drs.first(); drs.isRowPresent();)
					{
						
						
						if (testTodUser.equals(drs.getStringValueByName("dName")))
						{
							
							email = drs.getStringValueByName("dEmail");
							user = drs.getStringValueByName("dName");
						}
						
						drs.next();
					}
					
					if (!email.equals("")) {
						
						InternetFunctions.sendMailTo(email, "defaultMailTemplate", subjekt, this);
					}
				}
				
				/*if (!porukaDokumentiMax.equals(""))
				{

					DataResultSet drs1 = SharedObjects.getTable("Users");

					String email1 = "";
					String user1 = "";
					String userFullName1 = "";
					String uUstrojnaJedinica1 = "";
					
					for (drs1.first(); drs1.isRowPresent();)
					{
						
						
						if (new File(rootPath).getParent().substring(new File(rootPath).getParent().lastIndexOf("\\") + 1, new File(rootPath).getParent().length()).equals(drs1.getStringValueByName("dName")))
						{
							
							email1 				= drs1.getStringValueByName("dEmail");
							user1 				= drs1.getStringValueByName("dName");
							userFullName1 		= drs1.getStringValueByName("dFullName");
							uUstrojnaJedinica1 	= drs1.getStringValueByName("uUstrojnaJedinica");
							
						}
						
						drs1.next();
					}*/
					
					
					//if (!email1.equals(""))
					//{
						
						// za rukovoditelja
						//String str = "Djelatnik " + userFullName1 + " ima na ovjeri račune više od 7 dana ";
						//str = str + " To: " + user1;
						
						//System.out.println(email1 + " " + str);
						
						// za zaposlenika
						//String str1 = "Račune je potrebno odobriti u sustavu ili vratiti dobavljaču ukoliko usluga nije izvršena/roba nije isporučena";
						//str1 = str1 + " To: " + user1;
						
						//System.out.println(str1 + " " + str1);
						
						// ovo treba ici zaposleniku
						//InternetFunctions.sendMailTo(email1, "defaultMailTemplate1", str1, this);
						// i treba napraviti metodu koja će poslati rukovoditelju mail
						//System.out.println(uUstrojnaJedinica1 + " " + uUstrojnaJedinica1);
						//sendMailRukovoditelju(str,uUstrojnaJedinica1,this,this.m_workspace);
						
						
					//}
				//}
				
				
			}
		}
		
		this.m_binder.putLocal("RedirectUrl", "<$HttpCgiPath$>?IdcService=NDAY_FORM");
			
	}

	
	public void testSend() throws ServiceException, DataException {
		
		String testdUser = this.m_binder.getLocal("testdUser");
		String testTodUser = this.m_binder.getLocal("testTodUser");


		String everyNDays = "";
		String hourToExec = "";
		String longerThanInDays = "";
		String mailSubject = "";
		String mailMessage = "";
		String selectMetadata = "";
		String defaultDDocName = "";
		String defaultDDocTitle = "";
		String maxDays = "";
		
		try
		{
			FileInputStream fstream = new FileInputStream(ComponentLoader.getComponentDir("NDayComponent") + "\\templates\\nDay_config.cfg");

			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			while ((strLine = br.readLine()) != null)
			{

				String tmpName = strLine.substring(0, strLine.indexOf("="));
				String tmpValue = strLine.substring(strLine.indexOf("=") + 1, strLine.length());

				//System.out.println(tmpName + "=" + tmpValue);
				if (tmpName.equals("everyNDays")) {
					everyNDays = tmpValue;
				}
				if (tmpName.equals("hourToExec")) {
					hourToExec = tmpValue;
				}
				if (tmpName.equals("longerThanInDays")) {
					longerThanInDays = tmpValue;
				}
				if (tmpName.equals("mailSubject")) {
					mailSubject = tmpValue;
				}
				if (tmpName.equals("mailMessage")) {
					mailMessage = tmpValue;
				}
				if (tmpName.equals("selectMetadata")) {
					selectMetadata = tmpValue;
				}
				if (tmpName.equals("defaultDDocName")) {
					defaultDDocName = tmpValue;
				}
				if (tmpName.equals("defaultDDocTitle")) {
					defaultDDocTitle = tmpValue;
				}
				if (tmpName.equals("maxDays")) {
					maxDays = tmpValue;
				}
			}
			in.close();
		}
		catch (Exception e)
		{
			System.out.println("File nDay_config.cfg can't be found!");
		}
		String rootPath = DirectoryLocator.getUserProfilesDir();
		ProcessOne(new File(rootPath), this.m_binder, this, mailSubject, mailMessage, this.m_workspace, selectMetadata, everyNDays, defaultDDocName, defaultDDocTitle, testdUser, testTodUser, longerThanInDays, maxDays);

		this.m_binder.putLocal("RedirectUrl", "<$HttpCgiPath$>?IdcService=NDAY_FORM");
			}

	static int spc_count = -1;

	static void ProcessOne(File aFile, DataBinder db, ExecutionContext cxt, String mailSubject, String mailMessage, Workspace wks, String selectMetadata, String everyNDays, String defaultDDocName, String defaultDDocTitle, String testdUser, String testTodUser, String longerThanInDays,String maxDays) throws ServiceException, DataException {
	
		spc_count += 1;
		String spcs = "";

		DataBinder serviceBinder = new DataBinder(SharedObjects.getSafeEnvironment());
		for (int i = 0; i < spc_count; i++) {
			spcs = spcs + " ";
		}
		if (aFile.isFile())
		{
			if (aFile.getName().equals("wf_in_queue.hda"))
			{
				
				if (aFile.getParent().substring(aFile.getParent().lastIndexOf("\\") + 1, aFile.getParent().length()).equals(testdUser))
				{
					ResourceUtils.serializeDataBinder(FileUtils.getDirectory(aFile.toString()), FileUtils.getName(aFile.toString()), serviceBinder, false, true);

					Map map = serviceBinder.m_resultSets;

					serviceBinder.clearResultSets();
					serviceBinder.getLocalData().clear();

					DataResultSet resultSetDocumentsInWF = (DataResultSet)map.get("WorkflowInQueue");
					if (resultSetDocumentsInWF != null)
					{
						String subjekt = mailSubject;
						
						String poruka = mailMessage + "<br><br>";
						//String poruka1 = "<br><br>";

						poruka = poruka + "<table border=1>";
						//poruka1 = poruka1 + "<table border=1>";

						String porukaDokumenti = "";
						//String porukaDokumentiMax = "";

						int cnt = 1;
						//int cnt1 = 1;
						
						for (resultSetDocumentsInWF.first(); resultSetDocumentsInWF.isRowPresent();)
						{
							
							String dIDDocInWF = resultSetDocumentsInWF.getStringValueByName("dID");
							String dDocNameDocInWF = resultSetDocumentsInWF.getStringValueByName("dDocName");
							Timestamp wfQueueEnterTs = new Timestamp(resultSetDocumentsInWF.getDateValueByName("wfQueueEnterTs").getTime());

							Timestamp trenutniDatumTs = new Timestamp(new Date().getTime());

							long razlikaDatuma = Math.abs(trenutniDatumTs.getTime() - wfQueueEnterTs.getTime());

							Long longerThanInDaysLong = new Long(longerThanInDays);
							Long maxDaysLong = new Long(maxDays); //ovo je uvedeno zato jel su htjeli ako je račun kod korisnika više od 7 dana nije obrađen treba se poslati njegovom rukovoditelju i njemu samome 
							
							if (razlikaDatuma > new Long(longerThanInDaysLong.longValue() * 24L * 60L * 60L * 1000L).longValue())
							{
								String sqlSelectMetadata = selectMetadata;
								
								if (!selectMetadata.equals("")) {
									sqlSelectMetadata = selectMetadata + ",";
								}
								String sqlGetCustom = "select " + sqlSelectMetadata + " dDocTitle from docmeta,revisions where docmeta.did=revisions.did and docmeta.did=" + dIDDocInWF;
								ResultSet tempCustom = wks.createResultSetSQL(sqlGetCustom);

								String tempdefaultDDocName = "";
								
								if (defaultDDocName.equals("on")) {
									tempdefaultDDocName = 
											"<td><a href='<$HttpCgiPath$>?IdcService=REVIEW_WORKFLOW_DOC&dDocName=" + dDocNameDocInWF + "'>" + dDocNameDocInWF + "</a></td>";
								}
								
								String tempdefaultDDocTitle = "";
								
								if (defaultDDocTitle.equals("on")) {
									tempdefaultDDocTitle = "<td align=right>" + tempCustom.getStringValueByName("dDocTitle") + "</td>";
								}
								
								String tdSelectMetadata = "";
								
								if (!selectMetadata.equals("")) {
									
									if (tempCustom.getStringValueByName(selectMetadata) == null) {
										tdSelectMetadata = "<td align=center></td>";
									} else {
										tdSelectMetadata = "<td align=center>" + tempCustom.getStringValueByName(selectMetadata) + "</td>";
									}
								}
								
								porukaDokumenti = porukaDokumenti + "<tr><td align=right>" + cnt + ".</td>" + tempdefaultDDocName + tempdefaultDDocTitle + tdSelectMetadata + "<td align=right>>" + new Long(razlikaDatuma / 86400000L).intValue() + "_days</td>" + "</tr>";

								cnt++;
							}
							
							// ovdje provjeravamo dali je račun više od 7 dana kod korisnika
							//if (razlikaDatuma > new Long(maxDaysLong.longValue() * 24L * 60L * 60L * 1000L).longValue())
							//{
								
								
								// prvo si preprim listu računa koji su više od 7 dana
								//String sqlGetMeta1 = 
									//	"select xUrudzbeniBroj,dDocTitle,xTipDokumenta,xStatusDokumenta,dDocName " + 
									//	"from docmeta,revisions where docmeta.did=revisions.did and docmeta.did=" + dIDDocInWF;
								
								/*ResultSet tempRS1 = wks.createResultSetSQL(sqlGetMeta1);
								
								String sUrBroj1 = tempRS1.getStringValueByName("xUrudzbeniBroj");
								String sDocTitle1 = tempRS1.getStringValueByName("dDocTitle");
								String sTipDoc1 = tempRS1.getStringValueByName("xTipDokumenta");
								String sStatDok1 = tempRS1.getStringValueByName("xStatusDokumenta");
								String sDokName1 = tempRS1.getStringValueByName("dDocName");
								
								
								if(sTipDoc1.equals("Račun")) {
									
									if(sStatDok1.equals("Na zaduženju") || sStatDok1.equals("na odobrenju")) {
										
										porukaDokumentiMax = porukaDokumentiMax + "<tr><td align=right>" + cnt1 + ".</td><td>" + sUrBroj1 + "</td></tr>";
										System.out.println("porukaDokumentiMax " + porukaDokumentiMax);
									}
								}
								
								
								
								cnt1++;
							}*/
							
							resultSetDocumentsInWF.next();
						}
						
						
						poruka = poruka + porukaDokumenti + "</table>";
						poruka = poruka + "<br>Total documents: " + (cnt - 1) + "<br><br>";
						serviceBinder.putLocal("poruka", poruka);
						db.putLocal("poruka", poruka);
						
						/*poruka1 = poruka1 + porukaDokumentiMax + "</table>";
						poruka1 = poruka1 + "<br>Total documents: " + (cnt1 - 1) + "<br><br>";
						serviceBinder.putLocal("poruka1", poruka1);
						db.putLocal("poruka1", poruka1);*/

						
						if (!porukaDokumenti.equals(""))
						{

							DataResultSet drs = SharedObjects.getTable("Users");

							String email = "";
							String user = "";
							for (drs.first(); drs.isRowPresent();)
							{
								
								
								if (aFile.getParent().substring(aFile.getParent().lastIndexOf("\\") + 1, aFile.getParent().length()).equals(drs.getStringValueByName("dName")))
								{
								
									email = drs.getStringValueByName("dEmail");
									user = drs.getStringValueByName("dName");
								}
								
								drs.next();
							}
							
							if (!email.equals(""))
							{
								subjekt = subjekt + " To: " + user;
								InternetFunctions.sendMailTo(email, "defaultMailTemplate", subjekt, cxt);
							}
						}
						
						/*if (!porukaDokumentiMax.equals(""))
						{

							DataResultSet drs1 = SharedObjects.getTable("Users");

							String email1 = "";
							String user1 = "";
							String userFullName1 = "";
							String uUstrojnaJedinica1 = "";
							
							for (drs1.first(); drs1.isRowPresent();)
							{
								
								
								if (aFile.getParent().substring(aFile.getParent().lastIndexOf("\\") + 1, aFile.getParent().length()).equals(drs1.getStringValueByName("dName")))
								{
									
									email1 				= drs1.getStringValueByName("dEmail");
									user1 				= drs1.getStringValueByName("dName");
									userFullName1 		= drs1.getStringValueByName("dFullName");
									uUstrojnaJedinica1 	= drs1.getStringValueByName("uUstrojnaJedinica");
									
								}
								
								drs1.next();
							}*/
							
							
							//if (!email1.equals(""))
							//{
								
								// za rukovoditelja
								//String str = "Djelatnik " + userFullName1 + " ima na ovjeri račune više od 7 dana ";
								//str = str + " To: " + user1;
								
								//System.out.println(email1 + " " + str);
								
								// za zaposlenika
								//String str1 = "Račune je potrebno odobriti u sustavu ili vratiti dobavljaču ukoliko usluga nije izvršena/roba nije isporučena";
								//str1 = str1 + " To: " + user1;
								
								//System.out.println(str1 + " " + str1);
								
								// ovo treba ici zaposleniku
								//InternetFunctions.sendMailTo(email1, "defaultMailTemplate1", str1, cxt);
								// i treba napraviti metodu koja će poslati rukovoditelju mail
								//System.out.println(uUstrojnaJedinica1 + " " + uUstrojnaJedinica1);
								//sendMailRukovoditelju(str,uUstrojnaJedinica1,cxt,wks);
								
								
							//}
						//}
						
						
					}
					
				}
				
			}
			
		}
		else if (aFile.isDirectory())
		{
			File[] listOfFiles = aFile.listFiles();
			if (listOfFiles != null) {
				for (int i = 0; i < listOfFiles.length; i++) {
					ProcessOne(listOfFiles[i], db, cxt, mailSubject, mailMessage, wks, selectMetadata, everyNDays, defaultDDocName, defaultDDocTitle, testdUser, testTodUser, longerThanInDays,maxDays);
				}
			}
		}
		spc_count -= 1;
	}
	
	

	static void readFile(File file)
	{
		try
		{
			FileInputStream fstream = new FileInputStream(file);

			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			while ((strLine = br.readLine()) != null)
			{

				//System.out.println(strLine);
			}
			in.close();
		}
		catch (Exception e)
		{
			System.err.println("Error: " + e.getMessage());
		}
	}
	
	// ako je više od 7 dana
	/*static void sendMailRukovoditelju(String subjekt,String uUstrojnaJedinica1, ExecutionContext cxt, Workspace wks) throws DataException {
		
		String sqlGetCustom1 = "select RUKOVODITELJ_SIFRA,RUKOVODITELJ_IME,RUKOVODITELJ_PREZIME,RUKOVODITELJ_EMAIL from v_djelatnici where sifra = " + uUstrojnaJedinica1;
	    
		ResultSet tempCustom1 = wks.createResultSetSQL(sqlGetCustom1);
		*/
		
		//String rukovoditeljSifra = tempCustom1.getStringValue(0);
		//String rukovoditeljIme = tempCustom1.getStringValue(1);
		//String rukovoditeljPrezime = tempCustom1.getStringValue(2);
		/*String rukovoditeljEmail = tempCustom1.getStringValue(3);
		
		
		System.out.println("sqlGetCustom1: " + sqlGetCustom1);
		System.out.println("Rukovoditelj: " + rukovoditeljEmail);
		InternetFunctions.sendMailTo(rukovoditeljEmail, "defaultMailTemplate1", subjekt, cxt);
		
		System.out.println("KRAJ ");
	}*/
	
}
