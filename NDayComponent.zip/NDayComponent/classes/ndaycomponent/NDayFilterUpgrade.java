package ndaycomponent;

import intradoc.common.ExecutionContext;
import intradoc.common.FileUtils;
import intradoc.common.ServiceException;
import intradoc.common.SystemUtils;
import intradoc.data.DataBinder;
import intradoc.data.DataException;
import intradoc.data.DataResultSet;
import intradoc.data.ResultSet;
import intradoc.data.Workspace;
import intradoc.resource.ResourceUtils;
import intradoc.server.ComponentLoader;
import intradoc.server.DirectoryLocator;
import intradoc.server.IdcSystemLoader;
import intradoc.server.InternetFunctions;
import intradoc.server.ScheduledSystemEvents;
import intradoc.shared.FilterImplementor;
import intradoc.shared.SharedObjects;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Map;
import java.util.StringTokenizer;

public class NDayFilterUpgrade
implements FilterImplementor
{
	public int doFilter(Workspace ws, DataBinder eventData, ExecutionContext cxt)
			throws DataException, ServiceException
			{
		String action = eventData.getLocal("action");

		if (action.equals("CustomHourlyEvent"))
		{
			doCustomHourlyEvent(ws, eventData, cxt);
			return 1;
		}

		return 0;
			}

	protected void doCustomHourlyEvent(Workspace ws, DataBinder eventData, ExecutionContext cxt)
			throws DataException, ServiceException
			{
		update("CustomHourlyEvent", "event starting...", ws);

		trace("doing custom hourly event");

		String everyNDays = "";
		String hourToExec = "";
		String longerThanInDays = "";
		String mailSubject = "";
		String mailMessage = "";
		String selectMetadata = "";
		String defaultDDocName = "";
		String defaultDDocTitle = "";
		String maxDays = "";

		try
		{
			FileInputStream fstream = new FileInputStream(ComponentLoader.getComponentDir("NDayComponent") + "\\templates\\nDay_config.cfg");

			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			while ((strLine = br.readLine()) != null)
			{

				String tmpName = strLine.substring(0, strLine.indexOf("="));
				String tmpValue = strLine.substring(strLine.indexOf("=") + 1, strLine.length());
				if (tmpName.equals("everyNDays")) {
					everyNDays = tmpValue;
				}
				if (tmpName.equals("hourToExec")) {
					hourToExec = tmpValue;
				}
				if (tmpName.equals("longerThanInDays")) {
					longerThanInDays = tmpValue;
				}
				if (tmpName.equals("mailSubject")) {
					mailSubject = tmpValue;
				}
				if (tmpName.equals("mailMessage")) {
					mailMessage = tmpValue;
				}
				if (tmpName.equals("selectMetadata")) {
					selectMetadata = tmpValue;
				}
				if (tmpName.equals("defaultDDocName")) {
					defaultDDocName = tmpValue;
				}
				if (tmpName.equals("defaultDDocTitle")) {
					defaultDDocTitle = tmpValue;
				}
				if (tmpName.equals("maxDays")) {
					maxDays = tmpValue;
				}
			}
			in.close();
		}
		catch (Exception e)
		{
			System.out.println("Workflow reminder component - config file nDay_config.cfg can't be found!");
		}
		if ((!hourToExec.equals("")) && (!longerThanInDays.equals("")))
		{
			Calendar calendar = new GregorianCalendar();

			int currHour = calendar.get(11);
			int hourToExecInt = new Integer(hourToExec).intValue();
			if (hourToExecInt == currHour) {
				ProcessAll(new File(DirectoryLocator.getUserProfilesDir()), eventData, cxt, mailSubject, mailMessage, ws, selectMetadata, everyNDays, defaultDDocName, defaultDDocTitle, longerThanInDays, maxDays);
			}
		}
		update("CustomHourlyEvent", "event finished successfully", ws);
			}

	protected void update(String action, String msg, Workspace workspace) throws ServiceException, DataException {
		
		long curTime = System.currentTimeMillis();
		ScheduledSystemEvents sse = IdcSystemLoader.getOrCreateScheduledSystemEvents(workspace);
		sse.updateEventState(action, msg, curTime);
	}

	protected void trace(String str)
	{
		SystemUtils.trace("scheduledevents", "- custom - " + str);
	}

	static int spc_count = -1;

	static void ProcessAll(File aFile, DataBinder db, ExecutionContext cxt, String mailSubject, String mailMessage, Workspace wks, String selectMetadata, String everyNDays, String defaultDDocName, String defaultDDocTitle, String longerThanInDays, String maxDays) throws ServiceException, DataException
	{
		
		spc_count += 1;
		String spcs = "";

		DataBinder serviceBinder = new DataBinder(SharedObjects.getSafeEnvironment());
		
		for (int i = 0; i < spc_count; i++) {
			spcs = spcs + " ";
		}
		
		if (aFile.isFile())
		{
			if (aFile.getName().equals("wf_in_queue.hda"))
			{
				ResourceUtils.serializeDataBinder(FileUtils.getDirectory(aFile.toString()), FileUtils.getName(aFile.toString()), serviceBinder, false, true);

				Map map = serviceBinder.m_resultSets;

				serviceBinder.clearResultSets();
				serviceBinder.getLocalData().clear();

				DataResultSet resultSetDocumentsInWF = (DataResultSet)map.get("WorkflowInQueue");
				if (resultSetDocumentsInWF != null)
				{
					String subjekt = mailSubject;
					String poruka = mailMessage + "<br><br>";
					//String poruka1 = "<br><br>";

					poruka = poruka + "<table border=1>";
					//poruka1 = poruka1 + "<table border=1>";

					String porukaDokumenti = "";
					//String porukaDokumentiMax = "";


					int cnt = 1;
					//int cnt1 = 1;


					for (resultSetDocumentsInWF.first(); resultSetDocumentsInWF.isRowPresent();)
					{
						String dIDDocInWF = resultSetDocumentsInWF.getStringValueByName("dID");
						String dDocNameDocInWF = resultSetDocumentsInWF.getStringValueByName("dDocName");
						Timestamp wfQueueEnterTs = new Timestamp(resultSetDocumentsInWF.getDateValueByName("wfQueueEnterTs").getTime());

						Timestamp trenutniDatumTs = new Timestamp(new Date().getTime());

						GregorianCalendar gcal = new GregorianCalendar();
						Date start = resultSetDocumentsInWF.getDateValueByName("wfQueueEnterTs");
						Date end = new Date();
						gcal.setTime(start);

						int numWorkDaysBetweenDates = 0;
						while (gcal.getTime().before(end))
						{
							gcal.add(6, 1);
							if ((gcal.getTime().getDay() > 0) && (gcal.getTime().getDay() < 6)) {
								numWorkDaysBetweenDates++;
							}
						}

						Long longerThanInDaysLong = new Long(longerThanInDays);
						//Long maxDaysLong = new Long(maxDays); //ovo je uvedeno zato jel su htjeli ako je račun kod korisnika više od 7 dana nije obrađen treba se poslati njegovom rukovoditelju i njemu samome

						if (numWorkDaysBetweenDates > longerThanInDaysLong.intValue())
						{
							String sqlSelectMetadata = selectMetadata;
							if (!selectMetadata.equals("")) {
								sqlSelectMetadata = selectMetadata + ",";
							}
							String sqlGetCustom = "select " + sqlSelectMetadata + " dDocTitle from docmeta,revisions where docmeta.did=revisions.did and docmeta.did=" + dIDDocInWF;
							ResultSet tempCustom = wks.createResultSetSQL(sqlGetCustom);

							String tempdefaultDDocName = "";
							if (defaultDDocName.equals("on")) {
								tempdefaultDDocName = 
										"<td><a href='<$HttpCgiPath$>?IdcService=REVIEW_WORKFLOW_DOC&dDocName=" + dDocNameDocInWF + "'>" + dDocNameDocInWF + "</a></td>";
							}
							
							String tempdefaultDDocTitle = "";
							
							if (defaultDDocTitle.equals("on")) {
								tempdefaultDDocTitle = "<td align=right>" + tempCustom.getStringValueByName("dDocTitle") + "</td>";
							}
							
							String tdSelectMetadata = "";
							
							if (!selectMetadata.equals("")) {
								
								if (tempCustom.getStringValueByName(selectMetadata) == null) {
									tdSelectMetadata = "<td align=center></td>";
								} else {
									tdSelectMetadata = "<td align=center>" + tempCustom.getStringValueByName(selectMetadata) + "</td>";
								}
								
							}
							
							porukaDokumenti = porukaDokumenti + "<tr><td align=right>" + cnt + ".</td>" + tempdefaultDDocName + tempdefaultDDocTitle + tdSelectMetadata + "<td align=right>>" + numWorkDaysBetweenDates + "_days</td>" + "</tr>";

							cnt++;
						}


						// ovdje provjeravamo dali je račun više od 7 dana kod korisnika
						/*if (numWorkDaysBetweenDates > maxDaysLong)
						{
						 */

							// prvo si preprim listu računa koji su više od 7 dana
							/*String sqlGetMeta1 = 
									"select xUrudzbeniBroj,dDocTitle,xTipDokumenta,xStatusDokumenta,dDocName " + 
											"from docmeta,revisions where docmeta.did=revisions.did and docmeta.did=" + dIDDocInWF;

							ResultSet tempRS1 = wks.createResultSetSQL(sqlGetMeta1);

							String sUrBroj1 = tempRS1.getStringValueByName("xUrudzbeniBroj");
							String sDocTitle1 = tempRS1.getStringValueByName("dDocTitle");
							String sTipDoc1 = tempRS1.getStringValueByName("xTipDokumenta");
							String sStatDok1 = tempRS1.getStringValueByName("xStatusDokumenta");
							String sDokName1 = tempRS1.getStringValueByName("dDocName");


							if("Račun".equals(sTipDoc1)) {

								if("Na zaduženju".equals(sStatDok1) || "na odobrenju".equals(sStatDok1)) {

									porukaDokumentiMax = porukaDokumentiMax + "<tr><td align=right>" + cnt1 + ".</td><td>" + sUrBroj1 + "</td></tr>";

								}
							}



							cnt1++;
						}*/

						resultSetDocumentsInWF.next();
					}





					poruka = poruka + porukaDokumenti + "</table>";
					poruka = poruka + "<br>Total documents: " + (cnt - 1) + "<br><br>";
					serviceBinder.putLocal("poruka", poruka);
					db.putLocal("poruka", poruka);


					/*poruka1 = poruka1 + porukaDokumentiMax + "</table>";
					poruka1 = poruka1 + "<br>Total documents: " + (cnt1 - 1) + "<br><br>";
					serviceBinder.putLocal("poruka1", poruka1);
					db.putLocal("poruka1", poruka1);*/




					if (!porukaDokumenti.equals(""))
					{
						DataResultSet drs = SharedObjects.getTable("Users");

						String email = "";
						String user = "";
						for (drs.first(); drs.isRowPresent();)
						{
							if (aFile.getParent().substring(aFile.getParent().lastIndexOf("\\") + 1, aFile.getParent().length()).equals(drs.getStringValueByName("dName")))
							{
								email = drs.getStringValueByName("dEmail");
								user = drs.getStringValueByName("dName");
							}
							drs.next();
						}
						String mailTemplate = "defaultMailTemplate";
						if (!email.equals(""))
						{
							InternetFunctions.sendMailTo(email, mailTemplate, subjekt, cxt);
							sendExtraMails(mailTemplate, subjekt, user, poruka, cxt);
						}
						else
						{
							sendExtraMails(mailTemplate, subjekt, user, poruka, cxt);
						}
					}


					//if (!porukaDokumentiMax.equals(""))
					//{

						//DataResultSet drs1 = SharedObjects.getTable("Users");

						/*String email1 = "";
						String user1 = "";
						String userFullName1 = "";
						String uUstrojnaJedinica1 = "";*/

						/*for (drs1.first(); drs1.isRowPresent();)
						{


							if (aFile.getParent().substring(aFile.getParent().lastIndexOf("\\") + 1, aFile.getParent().length()).equals(drs1.getStringValueByName("dName")))
							{

								email1 				= drs1.getStringValueByName("dEmail");
								user1 				= drs1.getStringValueByName("dName");
								userFullName1 		= drs1.getStringValueByName("dFullName");
								uUstrojnaJedinica1 	= drs1.getStringValueByName("uUstrojnaJedinica");

							}

							drs1.next();
						}*/


						//if (!email1.equals(""))
						//{

							// za rukovoditelja
							//String str = "Djelatnik " + userFullName1 + " ima na ovjeri račune više od 7 dana ";
							//str = str + " To: " + user1;

							// za zaposlenika
							//String str1 = "Račune je potrebno odobriti u sustavu ili vratiti dobavljaču ukoliko usluga nije izvršena/roba nije isporučena";
							//str1 = str1 + " To: " + user1;

							// ovo treba ici zaposleniku
							//InternetFunctions.sendMailTo(email1, "defaultMailTemplate1", str1, cxt);
							// i treba napraviti metodu koja će poslati rukovoditelju mail
							//sendMailRukovoditelju(str,uUstrojnaJedinica1,cxt,wks);


						//}
					//}




				}
			}
		}
		else if (aFile.isDirectory())
		{
			File[] listOfFiles = aFile.listFiles();
			if (listOfFiles != null) {
				for (int i = 0; i < listOfFiles.length; i++) {
					ProcessAll(listOfFiles[i], db, cxt, mailSubject, mailMessage, wks, selectMetadata, everyNDays, defaultDDocName, defaultDDocTitle, longerThanInDays, maxDays);
				}
			}
		}
		spc_count -= 1;
			}

	static void readFile(File file)
	{
		try
		{
			FileInputStream fstream = new FileInputStream(file);

			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			while ((strLine = br.readLine()) != null) {}
			in.close();
		}
		catch (Exception e)
		{
			System.err.println("Error: " + e.getMessage());
		}
	}

	public static void sendExtraMails(String mailTemplate, String subjekt, String user, String poruka, ExecutionContext ctx)
			throws ServiceException, DataException
			{
		String dUser = "";
		String mails = "";
		try
		{
			FileInputStream fstream = new FileInputStream(ComponentLoader.getComponentDir("NDayComponent") + "\\templates\\extraMailDefinition.cfg");

			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			while ((strLine = br.readLine()) != null)
			{

				String tmpUser = strLine.substring(0, strLine.indexOf(" "));
				String tmpMails = strLine.substring(strLine.indexOf(" ") + 1, strLine.length());
				if (tmpUser.equals(user))
				{
					
					

					StringTokenizer st = new StringTokenizer(tmpMails, ",");
					while (st.hasMoreTokens())
					{
						String mail = st.nextToken();
						

						InternetFunctions.sendMailTo(mail, mailTemplate, subjekt, ctx);
					}
				}
			}
			in.close();
		}
		catch (Exception e)
		{
			System.out.println("File extraMailDefinition.cfg can't be found!");
		}
			}


	//ako je više od 7 dana
	/*static void sendMailRukovoditelju(String subjekt,String uUstrojnaJedinica1, ExecutionContext cxt, Workspace wks) throws DataException {

		String sqlGetCustom1 = "select RUKOVODITELJ_SIFRA,RUKOVODITELJ_IME,RUKOVODITELJ_PREZIME,RUKOVODITELJ_EMAIL from v_djelatnici where sifra = " + uUstrojnaJedinica1;

		ResultSet tempCustom1 = wks.createResultSetSQL(sqlGetCustom1);
*/

		//String rukovoditeljSifra = tempCustom1.getStringValue(0);
		//String rukovoditeljIme = tempCustom1.getStringValue(1);
		//String rukovoditeljPrezime = tempCustom1.getStringValue(2);
		/*String rukovoditeljEmail = tempCustom1.getStringValue(3);

		if(rukovoditeljEmail != null) {

			if(!"".equals(rukovoditeljEmail)) {

				InternetFunctions.sendMailTo(rukovoditeljEmail, "defaultMailTemplate1", subjekt, cxt);
			}
		}


	}*/


}
